/* Carta da parceria: folha de caderno pautada sobre o fundo preto da seção 5, entre a foto do
   moletom da Wheff (topo da seção) e a calculadora. Marca-texto lima nas frases principais,
   grifos de caneta e anotações à mão na margem.
   Como o parceria.js, só entra DEPOIS que o React terminou. */
(function () {
  var M = function (t) { return '<mark class="wc-marca">' + t + "</mark>"; };   // marca-texto lima
  var G = function (t) { return '<span class="wc-grifo">' + t + "</span>"; };   // grifo de caneta

  // cartões de vidro: número, rótulo e texto, com um ponto lima no canto
  function cartao(n, rotulo, texto, extra, classe) {
    return '<article class="wc-cartao' + (classe ? " " + classe : "") + '"><span class="wc-ponto" aria-hidden="true"></span>' +
      '<span class="wc-num">' + n + "</span><h3>" + rotulo + "</h3><p>" + texto + "</p>" + (extra || "") + "</article>";
  }
  var SETA = '<svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>';

  var carta =
    '<section class="wc-sessao" id="carta" aria-labelledby="wc-titulo">' +
    '<div class="wc-folha">' +
    '<div class="wc-cabeca"><span class="wc-selo"><img src="./lp/logo-wheff-claro.png" alt="Wheff" width="640" height="170"></span><h2 id="wc-titulo" class="wc-titulo">A Parceria</h2></div>' +
    '<div class="wc-lado">' +
    '<p class="wc-abertura"><b>Trata-se de uma parceria</b> para ' + M("construir uma marca forte e memorável") + " e " + G("escalar suas vendas através de lançamentos digitais") +
    ", com " + G("metodologia própria") + ", estratégia e direcionamento em cada etapa.</p>" +
    '<p class="wc-frase">Sua marca é seu <em>' + G("maior ativo") + "</em>. Sua essência é sua <em>maior estratégia.</em></p>" +
    '<span class="wc-seta">' + SETA + "</span>" +
    "</div>" +
    '<div class="wc-grade">' +
    cartao("01", "O que unimos", "Unimos construção de marca forte e memorável a vendas com funis de lançamentos digitais atualizados, para transformar sua influência em uma marca própria que gera receita, fortalece sua presença e amplia o impacto do seu propósito.") +
    cartao("02", "O que assumimos", "Nós assumimos o operacional, com uma equipe preparada para cuidar do posicionamento, da identidade visual, do tráfego pago, das estratégias de vendas, dos funis, das automações e da inteligência artificial e todo conhecimento aplicado a sua marca.") +
    cartao("03", "O que você não precisa", "Você não precisa investir antecipadamente. Não precisa contratar uma equipe e também não precisa aprender tudo do absoluto zero.") +
    cartao("04", "Como construímos", "Construímos juntas uma marca forte e memorável e vendemos através de lançamentos escaláveis, preservando sua essência, sua personalidade e seu propósito para que você se reconheça em cada detalhe da sua marca.", "", "wc-largo") +
    cartao("05", "Como trabalhamos", "Acreditamos em resultados que vêm com trabalho inteligente: analisar o que funciona, aprimorar cada etapa e transformar aprendizado em crescimento.",
      '<p class="wc-filosofiaRotulo">Essa é a nossa filosofia:</p>' +
      '<p class="wc-filosofia"><span class="wc-circulo">Repetição Otimizada gera <em>Riqueza Escalonada.</em></span></p>', "wc-largo") +
    "</div></div></section>";

  // o marca-texto "passa" nas frases quando a folha aparece na tela
  function riscar(raiz) {
    if (!("IntersectionObserver" in window) || matchMedia("(prefers-reduced-motion: reduce)").matches) { raiz.classList.add("wc-ligado"); return; }
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { raiz.classList.add("wc-ligado"); io.disconnect(); } });
    }, { rootMargin: "0px 0px -25% 0px" });
    io.observe(raiz);
  }

  // luz que segue o mouse por cima dos cartões: cada cartão recebe a posição do cursor
  // relativa a ele, então a mesma luz acende também as bordas e o fundo dos vizinhos
  function lanterna(grade) {
    if (!grade || !matchMedia("(hover: hover)").matches) return;
    var cartoes = [].slice.call(grade.querySelectorAll(".wc-cartao"));
    grade.addEventListener("pointermove", function (e) {
      cartoes.forEach(function (c) {
        var r = c.getBoundingClientRect();
        c.style.setProperty("--mx", (e.clientX - r.left) + "px");
        c.style.setProperty("--my", (e.clientY - r.top) + "px");
      });
    });
  }

  function montar() {
    if (document.getElementById("carta")) return;
    var calc = document.querySelector('[class*="sessao5_calcCabeca__"]');
    if (!calc) return;
    calc.insertAdjacentHTML("beforebegin", carta);
    riscar(document.querySelector("#carta .wc-folha"));
    lanterna(document.querySelector("#carta .wc-grade"));
  }

  function reactPronto(el) { for (var k in el) if (k.indexOf("__reactFiber") === 0) return true; return false; }

  // letra de mão das anotações (Caveat)
  var fonte = document.createElement("link");
  fonte.rel = "stylesheet";
  fonte.href = "https://fonts.googleapis.com/css2?family=Caveat:wght@500;700&display=swap";
  document.head.appendChild(fonte);
  var css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = "./extra/carta.css?v=25";
  document.head.appendChild(css);

  var voltas = 0;
  var t = setInterval(function () {
    var calc = document.querySelector('[class*="sessao5_calcCabeca__"]');
    if ((calc && reactPronto(calc)) || ++voltas > 200) { clearInterval(t); setTimeout(montar, 50); }
  }, 80);
})();
