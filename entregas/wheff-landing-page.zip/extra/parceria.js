/* Seção "A parceria" (acima da faixa "Conteúdo abre portas") + contato no rodapé.
   A página é gerada pelo Next e o React assume o HTML ao carregar; por isso este bloco só entra
   DEPOIS que o React terminou (senão ele estranha o HTML a mais e refaz a página sem ele). */
(function () {
  var WHATS = "https://wa.me/5571988364088";
  var MSG_PARCERIA = "?text=" + encodeURIComponent("Olá! Quero entender a parceria 50/50 da Wheff e ver meu plano inicial.");
  var MSG_CONTATO = "?text=" + encodeURIComponent("Olá! Vim pelo site da Wheff.");
  var SETA = '<svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7h10v10"></path><path d="M7 17 17 7"></path></svg>';

  // fotos de fundo da faixa: trocam sozinhas, sem setas, pontos ou números
  var FOTOS = [
    ["parceria-duas-4k.webp", "Duas mulheres rindo com os frascos da própria linha de produtos", "50% 18%"],
    ["parceria-podcast-4k.webp", "Criadora gravando um podcast no estúdio", "50% 28%"],
  ];
  var fotos = FOTOS.map(function (f, i) {
    return '<img class="wp-fundoFoto' + (i === 0 ? " wp-ativa" : "") + '" src="./lp/' + f[0] + '" alt="' + f[1] + '" style="object-position:' + f[2] + '" decoding="async">';
  }).join("");

  // faixa de cartões inclinados (o que construímos), no tamanho da faixa do método
  function peca(tipo, texto) { return '<div class="wp-peca' + (tipo ? " " + tipo : "") + '">' + (texto || "") + "</div>"; }
  var pecas =
    peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro") +
    peca("wp-pecaVidro") + peca("", "Lançamento") + peca("wp-pecaEscura", "Funis") + peca("", "Plataforma de comunidade") + peca("wp-pecaEscura", "App") + peca("", "Curso") + peca("wp-pecaEscura", "Mentoria") + peca("wp-pecaTraco") +
    peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro");
  // no celular a faixa é estreita: as 6 peças vão em 2 fileiras de 3
  var vazio = peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco") + peca("wp-pecaVidro") + peca("wp-pecaTraco");
  var pecasCel =
    vazio +
    peca("wp-pecaVidro") + peca("", "Lançamento") + peca("wp-pecaEscura", "Funis") + peca("", "Plataforma de comunidade") + peca("wp-pecaTraco") +
    peca("wp-pecaTraco") + peca("wp-pecaEscura", "App") + peca("", "Curso") + peca("wp-pecaEscura", "Mentoria") + peca("wp-pecaVidro") +
    vazio;
  var faixaPecas =
    '<div class="wp-pecas wp-revela" role="img" aria-label="O que construímos com você: lançamento, funis, plataforma de comunidade, app, curso e mentoria">' +
    '<div class="wp-pecasPlano">' + pecas + "</div>" +
    '<div class="wp-pecasPlano wp-pecasCel">' + pecasCel + "</div></div>";

  var secao =
    '<section class="wp-sessao" id="parceria" aria-labelledby="wp-titulo">' +
    '<div class="wp-cabeca wp-revela">' +
    '<span class="wp-chapeu">A parceria</span>' +
    '<h2 id="wp-titulo" class="wp-titulo">Você entra com a sua voz. <em>A gente entra com toda a estrutura.</em></h2>' +
    '<p class="wp-apoio">Uma parceria de verdade para transformar a sua autoridade e a sua audiência em uma marca que vende, escala e leva o seu propósito ainda mais longe.</p>' +
    "</div>" +
    '<div class="wp-faixa wp-revela">' +
    '<div class="wp-fundo">' + fotos + "</div>" +
    '<div class="wp-faixaTexto">' +
    "<h3>Você só faz o que já ama: <em>gravar, ensinar e inspirar.</em></h3>" +
    "<p>Estratégia, equipe, design, funil, tráfego, páginas e textos de venda, suporte e a criação dos seus produtos ficam por nossa conta.</p>" +
    "</div></div>" +
    '<div class="wp-trio">' +
    '<article class="wp-cartao wp-revela"><h4>Você entra com <em>o que já faz</em></h4>' +
    "<p>Seu conteúdo, sua imagem, sua voz e sua influência. Sem montar equipe, sem aprender tráfego, sem se preocupar com o operacional.</p>" +
    '<div class="wp-visual"><div class="wp-fichas"><span>Sua voz</span><span>Conteúdo</span><span>Imagem</span><span>Influência</span></div></div></article>' +
    '<article class="wp-cartao wp-revela"><h4>A gente entra com <em>toda a estrutura</em></h4>' +
    "<p>Da estratégia ao lançamento, incluindo a criação dos seus produtos: cursos, mentorias, aplicativos e comunidades.</p>" +
    '<div class="wp-visual"><ul class="wp-lista"><li>Estratégia</li><li>Design</li><li>Lançamento</li><li>Funil</li><li>Tráfego</li><li>Páginas e textos de venda</li><li>Produtos</li><li>Suporte</li></ul></div></article>' +
    '<article class="wp-cartao wp-revela"><h4>50/50, <em>justo e honesto</em></h4>' +
    "<p>Dividimos o lucro só do que construímos juntas. Você não investe nada antecipadamente; tráfego pago, só se quiser investir.</p>" +
    '<div class="wp-visual wp-meio"><div class="wp-rosca" aria-hidden="true"><span>50/50</span></div><small><b>Sem custo para começar.</b> Tudo no seu tempo, no seu ritmo e com a sua aprovação.</small></div></article>' +
    "</div>" +
    faixaPecas +
    '<div class="wp-metodo wp-revela">' +
    "<p>Pelo método <img class=\"wp-essenzia\" src=\"./lp/essenzia-logo.webp\" alt=\"Essenzia\" width=\"1000\" height=\"151\">, construção de marca e lançamentos digitais andam juntos: uma estrutura com a sua personalidade, para vender mais, construir legado e alcançar mais vidas com a sua voz.</p>" +
    '<a class="wp-cta" href="' + WHATS + MSG_PARCERIA + '" target="_blank" rel="noopener">Quero ver meu plano inicial<span class="wp-ctaSeta" aria-hidden="true">' + SETA + "</span></a>" +
    "</div></section>";

  var contato =
    '<div class="wp-contato" id="contato">' +
    '<p class="wp-versiculo">“Porque sou eu que conheço os planos que tenho para vocês, diz o Senhor, planos de fazê-los prosperar e não de causar dano, planos de dar a vocês esperança e um futuro.” <cite>Jeremias 29:11</cite></p>' +
    '<a href="' + WHATS + MSG_CONTATO + '" target="_blank" rel="noopener">WhatsApp (71) 98836-4088</a>' +
    '<span aria-hidden="true">·</span>' +
    '<a href="mailto:wheffstudio@gmail.com">wheffstudio@gmail.com</a></div>';

  function revelar(raiz) {
    var itens = raiz.querySelectorAll(".wp-revela");
    if (!("IntersectionObserver" in window)) return;
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.remove("wp-oculto"); io.unobserve(e.target); } });
    }, { rootMargin: "0px 0px -10% 0px" });
    itens.forEach(function (el, i) {
      if (el.getBoundingClientRect().top < innerHeight) return; // o que já está na tela não some
      el.classList.add("wp-oculto");
      el.style.transitionDelay = (i % 3) * 90 + "ms";
      io.observe(el);
    });
  }

  // troca a foto de fundo a cada 5 s (para quem pede menos movimento, fica na primeira)
  function trocarFotos(raiz) {
    var imgs = raiz.querySelectorAll(".wp-fundoFoto");
    if (imgs.length < 2 || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    var i = 0;
    setInterval(function () {
      imgs[i].classList.remove("wp-ativa");
      i = (i + 1) % imgs.length;
      imgs[i].classList.add("wp-ativa");
    }, 5000);
  }

  // seção "A escolha": a foto da criadora de óculos ganha a foto da mãe com o bebê ao lado, no mesmo cartão
  function juntarFotoMae() {
    var fig = document.querySelector('[class*="sessao6_foto__"]');
    if (!fig || document.querySelector(".wp-fotoMae")) return;
    fig.classList.add("wp-fotoDupla");
    // foto original inteira (em pé), com a camisa no lima da Wheff
    var img = fig.querySelector("img");
    if (img) { img.src = "./lp/criadora-lima-v2.webp"; img.removeAttribute("srcset"); img.alt = "Criadora de óculos e camisa listrada lima, fazendo uma selfie"; }
    // a mãe com o bebê vai na coluna da direita, no espaço vazio embaixo do texto
    var coluna = document.querySelector('[class*="sessao6_coluna__"]');
    var mae = '<figure class="wp-fotoMae"><img src="./lp/parceria-mae-v5.webp" alt="Mãe com o bebê no colo no estúdio da própria marca de roupas" decoding="async"></figure>';
    (coluna || fig).insertAdjacentHTML(coluna ? "beforeend" : "afterend", mae);
  }

  // "A influência trouxe você até aqui / Agora é a sua marca…" sobe e vira o título da faixa da placa
  function titulosAntesDaPlaca() {
    var faixa = document.querySelector('[class*="sessao6_faixa__"]');
    if (!faixa || document.querySelector(".wp-titulosPlaca")) return;
    var cabecas = document.querySelectorAll('[class*="sessao6_bloco__"] > [class*="sessao6_cabeca__"]');
    var alvo = null;
    cabecas.forEach(function (c) { if (/influ[êe]ncia trouxe/i.test(c.textContent)) alvo = c; });
    if (!alvo) return;
    var caixa = document.createElement("div");
    caixa.className = "wp-titulosPlaca";
    faixa.parentNode.insertBefore(caixa, faixa);
    caixa.appendChild(alvo);
  }

  // seção 1: quinta foto (maior). No computador fica embaixo do botão e da seta; no celular, embaixo das 4 fotos.
  function fotoNovaTopo() {
    if (document.querySelector(".wp-fotoNova")) return;
    var foto = '<img src="./lp/topo-tres.webp" alt="Três mulheres sorrindo com os frascos da própria linha de produtos" decoding="async">';
    var centro = document.querySelector('[class*="sessao1_centro__"]');
    var fotos = document.querySelector('[class*="sessao1_fotos__"]');
    var palco = document.querySelector('[class*="sessao1_palco__"]');
    if (palco) palco.classList.add("wp-palcoMaior");
    if (centro) centro.insertAdjacentHTML("beforeend", '<div class="wp-fotoNova wp-fotoPc">' + foto + "</div>");
    if (fotos) fotos.insertAdjacentHTML("beforeend", '<div class="wp-fotoNova wp-fotoCel">' + foto + "</div>");
  }

  // assinatura do fim (seção 6): a logo do método Essenzia ao lado da logo da Wheff
  function essenziaAssinatura() {
    var logo = document.querySelector('[class*="sessao6_assinaturaLogo__"]');
    if (!logo || document.querySelector(".wp-assinaturaDupla")) return;
    var caixa = logo.parentNode;
    caixa.classList.add("wp-assinaturaDupla");
    caixa.insertAdjacentHTML("beforeend", '<span class="wp-assinaturaTraco" aria-hidden="true"></span><img class="wp-assinaturaEssenzia" src="./lp/essenzia-logo.webp" alt="Método Essenzia" width="1000" height="151" decoding="async">');
  }

  // palavra curta ("e", "a", "de"…) nunca fica sozinha no fim da linha: gruda na palavra seguinte
  var CURTA = /(^|[\s (])(e|a|o|é|à|ao|as|os|de|da|do|em|no|na|um|se|ou) (?=\S)/gi;
  function semPalavraSolta(raiz) {
    var w = document.createTreeWalker(raiz, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) { return n.parentNode.closest("script,style,svg,textarea,input") ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; }
    });
    var n;
    while ((n = w.nextNode())) {
      var novo = n.nodeValue.replace(CURTA, function (m, antes, p) { return antes + p + " "; });
      novo = novo.replace(CURTA, function (m, antes, p) { return antes + p + " "; }); // pega "e a", "de o"… em sequência
      if (novo !== n.nodeValue) n.nodeValue = novo;
    }
  }

  function montar() {
    var faq = document.getElementById("faq");
    if (!faq || document.getElementById("parceria")) return;
    // logo acima da faixa "Conteúdo abre portas. Uma marca constrói legado."; sem ela, antes do FAQ
    var faixa = document.querySelector('[class*="sessao6_faixa__"]');
    (faixa || faq).insertAdjacentHTML("beforebegin", secao);
    faq.insertAdjacentHTML("beforeend", contato);
    var parceria = document.getElementById("parceria");
    if (faixa) parceria.classList.add("wp-dentro");
    revelar(parceria);
    trocarFotos(parceria);
    juntarFotoMae();
    titulosAntesDaPlaca();
    fotoNovaTopo();
    essenziaAssinatura();
    var main = document.querySelector("main") || document.body;
    semPalavraSolta(main);
    // respostas do FAQ entram na página só quando abertas
    new MutationObserver(function (ms) {
      ms.forEach(function (m) { m.addedNodes.forEach(function (el) { if (el.nodeType === 1) semPalavraSolta(el); }); });
    }).observe(faq, { childList: true, subtree: true });
  }

  function reactPronto(el) { for (var k in el) if (k.indexOf("__reactFiber") === 0) return true; return false; }

  var css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = "./extra/parceria.css?v=30";
  document.head.appendChild(css);

  var voltas = 0;
  var t = setInterval(function () {
    var faq = document.getElementById("faq");
    if ((faq && reactPronto(faq)) || ++voltas > 150) { clearInterval(t); setTimeout(montar, 50); }
  }, 80);
})();
