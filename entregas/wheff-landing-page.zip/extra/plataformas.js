/* Seção "Plataformas construídas pela Wheff": entre o banner do método Essenzia (fim da seção
   "A parceria") e a linha de "A influência trouxe você até aqui".
   Cartões empilhados que giram sozinhos a cada 3 s, sem botões nem pontinhos.
   Como o parceria.js, só entra DEPOIS que o React terminou e a seção da parceria já está na página. */
(function () {
  // só a imagem de cada tela, sem moldura nem nome
  var TELAS = [
    { foto: "./demos/wheff-login.webp", alt: "Plataforma Wheff: tela de login" },
    { foto: "./demos/kochav-dashboard.webp", alt: "Plataforma Kochav: dashboard com a visão geral da operação" },
    { foto: "./demos/princ-feed.webp", alt: "Rede social Princesas Celestiais: feed com o Explorar e as lives" },
  ];
  var INTERVALO = 3000;

  function cartao(t) {
    return '<figure class="wpl-cartao"><img src="' + t.foto + '" alt="' + t.alt + '" decoding="async"></figure>';
  }

  var secao =
    '<section class="wpl-sessao" id="plataformas" aria-labelledby="wpl-titulo">' +
    '<h2 id="wpl-titulo" class="wpl-titulo">Plataformas construídas pela <em>Wheff</em></h2>' +
    '<div class="wpl-palco">' + TELAS.map(cartao).join("") + "</div></section>";

  // -1 = à esquerda, 0 = na frente, 1 = à direita
  function distancia(i, atual, n) {
    var d = (((i - atual) % n) + n) % n;
    return d > n / 2 ? d - n : d;
  }

  function girar(cartoes) {
    var n = cartoes.length, atual = 0;
    function posicionar() {
      cartoes.forEach(function (c, i) {
        var d = distancia(i, atual, n);
        c.dataset.pos = d === 0 ? "frente" : d === 1 ? "direita" : d === -1 ? "esquerda" : "fora";
        c.setAttribute("aria-hidden", d === 0 ? "false" : "true");
      });
    }
    posicionar();
    setInterval(function () { atual = (atual + 1) % n; posicionar(); }, INTERVALO);
  }

  function montar() {
    if (document.getElementById("plataformas")) return;
    // logo depois do banner Essenzia; sem a seção da parceria, antes do FAQ
    var titulos = document.querySelector(".wp-titulosPlaca");
    var parceria = document.getElementById("parceria");
    var faq = document.getElementById("faq");
    if (titulos) titulos.insertAdjacentHTML("beforebegin", secao);
    else if (parceria) parceria.insertAdjacentHTML("afterend", secao);
    else if (faq) faq.insertAdjacentHTML("beforebegin", secao);
    else return;
    girar([].slice.call(document.querySelectorAll("#plataformas .wpl-cartao")));
  }

  var css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = "./extra/plataformas.css?v=8";
  document.head.appendChild(css);

  var voltas = 0;
  var t = setInterval(function () {
    if (document.querySelector(".wp-titulosPlaca") || ++voltas > 200) { clearInterval(t); setTimeout(montar, 50); }
  }, 80);
})();
